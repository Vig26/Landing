import React, { Suspense, lazy } from "react";
import { Route, Routes } from "react-router-dom";
import ScrollToTop from "./components/ScrollToTop";
import "./index.css";
import Header from "./layouts/Header";

/*****Pages******/
const Login = lazy(() => import("./pages/auth/Login"));
const Home = lazy(() => import("./pages/Home"));

const App = () => {
  return <AppRoutes />;
};

const AppRoutes = () => {
  return (
    <Suspense fallback={<div />}>
      <ScrollToTop />
      <Routes>
        <Route path="/" element={<Login />} exact />

        <Route element={<Header />}>
          <Route path="/home" element={<Home />} />
        </Route>
      </Routes>
    </Suspense>
  );
};

export default App;
