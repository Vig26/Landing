// import {
//   Grid,
//   Typography,
//   Avatar,
//   Card,
//   CardContent,
//   Box,
//   Link as MuiLink,
// } from "@mui/material";
// import React, { useEffect, useState } from "react";
// import { Link as RouterLink } from "react-router-dom";
// import useTitle from "../hooks/useTitle";
// import { useSelector } from "react-redux";
// import {
//   GetDashValues,
//   GetDashFunctions,
// } from "../services/dashborad.services";
// //import AssignmentIcon from "@mui/icons-material/Assignment";
// //import { styled } from "@mui/material/styles";
// import * as MuiIcons from "@mui/icons-material";

// const IconComponent = ({ icon }) => {
//   const MuiIcon = MuiIcons[icon];
//   console.log("Icons: ", icon, MuiIcon);
//   return MuiIcon ? (
//     <MuiIcon style={{ color: "white", fontSize: "30px" }} />
//   ) : null;
// };

// const DashboardCards = () => {
//   const title = "Dashboard";
//   useTitle(title);
//   const user = useSelector((state) => state.user);
//   const [userName, setUserName] = useState("");
//   const [dashboardMainData, setDashboardMainData] = useState();

//   const getInit = async () => {
//     let res = await GetDashValues({
//       userId: user.data.data.userdetails.user.userId,
//       // userId: "4",
//     });
//     console.log("res", res.data.result);
//     setUserName(user?.data?.data?.userdetails?.user?.userName);
//     setDashboardMainData(res.data.result?.dashboardRoleValues);

//     // let res1 = await GetDashFunctions({
//     //   attributeId: "1",
//     //   // userId: user.data.userdetails.user.userId,
//     //   userId: "34",
//     //   filterIdList: [],
//     // });
//     // console.log("res1", res1);
//   };

//   useEffect(() => {
//     getInit();
//   }, []);

//   return (
//     <Box
//       marginBottom={2}
//       display="flex"
//       flexDirection="column"
//       gap={2}
//       minHeight="75vh"
//     >
//       <Grid item>
//         <Typography variant="h4" fontWeight={"bold"} fontSize={"18px"}>
//           Welcome {userName}
//         </Typography>
//       </Grid>
//       {dashboardMainData?.length >= 1 && (
//         <Card
//           sx={{
//             //border:"0.5px solid black",
//             bgcolor: "#eeeeee",
//             flexGrow: 1,
//           }}
//         >
//           <CardContent>
//             {dashboardMainData?.map((item, index) => {
//               console.log("item", item);
//               return (
//                 <>
//                   <Typography
//                     variant="h2"
//                     //color="#777777"
//                     fontWeight="bold"
//                     fontFamily="Lato, sans-serif"
//                     fontSize="16px"
//                     marginTop={2}
//                     marginBottom={1}
//                     sx={{ flexGrow: 1, textDecoration: "underline" }}
//                   >
//                     {item?.roleName} ({item?.roleCode}):
//                   </Typography>
//                   <Grid
//                     container
//                     columnSpacing={2}
//                     rowSpacing={2}
//                     direction="row"
//                     justify="flex-end"
//                   >
//                     {item?.attributeLists?.map((data, index) => {
//                       return (
//                         <>
//                           <Grid xs={12} md={4} sm={6} item>
//                             <MuiLink
//                               component={RouterLink}
//                               to={data?.link}
//                               sx={{
//                                 textDecoration: "none",
//                                 cursor: data.link ? "pointer" : "default",
//                               }}
//                             >
//                               <Card
//                                 sx={{ borderLeft: "5px solid #2169b3" }} //#2169b3 //#8d6e63
//                               >
//                                 <CardContent>
//                                   <Box
//                                     display="flex"
//                                     justifyContent="space-between"
//                                     alignItems={"center"}
//                                   >
//                                     <Typography
//                                       variant="h2"
//                                       color="#777777" //"#777777" // #78909c
//                                       fontWeight={"600"}
//                                       fontSize={"15px"}
//                                       marginTop={"5px"}
//                                       sx={{ flexGrow: 1 }}
//                                     >
//                                       {data?.attributeName}
//                                     </Typography>
//                                     {data.icon && (
//                                       <Grid
//                                         width={"40px"}
//                                         height="40px"
//                                         borderRadius={"100%"}
//                                         //bgcolor={"red"}
//                                         display={"flex"}
//                                         alignItems="center"
//                                         justifyContent={"center"}
//                                       >
//                                         <Avatar
//                                           sx={{
//                                             bgcolor: data.colour
//                                               ? data.colour
//                                               : "green",
//                                           }} // #607d8b // #42a5f5 //#a1887f //#009688
//                                         >
//                                           {/* <AssignmentIcon /> */}
//                                           {/* <FormatListNumberedRtlSharpIcon
//                                   style={{ color: "white", fontSize: "30px" }}
//                                 /> */}
//                                           {/* <GradingIcon style={{ color: "white", fontSize: "30px" }} /> */}
//                                           <IconComponent icon={data.icon} />
//                                         </Avatar>
//                                       </Grid>
//                                     )}
//                                   </Box>
//                                   <Grid
//                                     mt={2}
//                                     display={"flex"}
//                                     alignItems="center"
//                                   >
//                                     <Typography
//                                       variant="h3"
//                                       sx={{
//                                         fontFamily: "Lato, sans-serif",
//                                         fontWeight: "bold",
//                                         color: data.colour
//                                           ? data.colour
//                                           : "green", //"green" //"#777777" //"#795548"
//                                       }}
//                                     >
//                                       {data?.counts}
//                                     </Typography>
//                                   </Grid>
//                                 </CardContent>
//                               </Card>
//                             </MuiLink>
//                           </Grid>
//                         </>
//                       );
//                     })}
//                   </Grid>
//                   {/* {dashboardMainData[index + 1] ? (
//               <Typography variant="h4" fontWeight={"bold"}></Typography>
//             ) : null} */}
//                 </>
//               );
//             })}
//           </CardContent>
//         </Card>
//       )}
//     </Box>
//   );
// };

// export default DashboardCards;
