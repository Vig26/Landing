import PropTypes from "prop-types";
import React from "react";
import { H3 } from "../components/Typography";
import { Divider, ListItemIcon } from "@mui/material";
import * as MuiIcons from "@mui/icons-material";

const HeadingDesign = ({ name, icon }) => {
  // Function to get the appropriate icon based on the name
  // const getIcon = (name) => {
  //   switch (name) {
  //     case HeadingNames.:
  //       return < />;

  //     default:
  //       return null; // Return null if name doesn't match any case
  //   }
  // };

  const getIcon = () => {
    const MuiIcon = MuiIcons[icon];
    return MuiIcon ? <MuiIcon style={{ fontSize: "30px" }} /> : null;
  };

  return (
    <>
      <div
        style={{
          display: "flex",
          justifyContent: "left",
          marginBlock: 5,
          marginTop: "10px",
          //borderBottom: "1px solid black",
          //color: "#2169b3",
        }}
      >
        <ListItemIcon style={{ color: "black" }}>
          {getIcon()}
          <H3
            marginLeft={0.5}
            display="flex"
            justifyContent="center"
            alignItems="flex-end"
          >
            {name}
          </H3>
        </ListItemIcon>
      </div>
      <Divider />
    </>
  );
};
HeadingDesign.propTypes = {
  name: PropTypes.string,
  icon: PropTypes.string,
};

export default HeadingDesign;
