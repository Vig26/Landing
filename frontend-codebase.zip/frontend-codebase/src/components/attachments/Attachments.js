import {
  Box,
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Grid,
  IconButton,
  Link,
  Paper,
  styled,
  Table,
  TableBody,
  TableCell,
  tableCellClasses,
  TableContainer,
  TableHead,
  TableRow,
  Typography,
  useMediaQuery,
} from "@mui/material";
// import { styled } from "@mui/system";
import AttachFileIcon from "@mui/icons-material/AttachFile";
import CloseIcon from "@mui/icons-material/Close";
import PictureAsPdf from "@mui/icons-material/PictureAsPdf";
import { useTheme } from "@mui/material/styles";
import axios from "axios";
import React, { useState } from "react";
import Draggable from "react-draggable";
import { DropzoneAreaBase } from "react-mui-dropzone";
//imports from this project
//import FileUpload from "../../components/FileUpload";
import DocViewer from "../../../../components/docViewer";
import { useSnackbar } from "../../../../components/Snackbar";
import FaceBookCircularProgress from "../FaceBookCircularProgress";

const StyledTableCell = styled(TableCell)(({ theme }) => ({
  [`&.${tableCellClasses.head}`]: {
    backgroundColor: "#78909c",
    color: theme.palette.common.white,
    fontSize: "16px",
    fontWeight: "bold",
  },
  [`&.${tableCellClasses.body}`]: {
    fontSize: "16px",
  },
}));

function PaperComponent(props) {
  return (
    <Draggable
      handle="#files-dialog-title"
      cancel={'[class*="MuiDialogContent-root"]'}
    >
      <Paper {...props} />
    </Draggable>
  );
}

const Attachments = (props) => {
  const {
    onUpload,
    fullWidth,
    maxWidth,
    maxNumberOfFiles,
    buttonName,
    dialogHeading,
    isDraggable,
    displayFileSize,
    displayThumbnail,
    dropzoneText,
    filesAccepted,
    displaySNo,
    showPreviewsInDropzone,
    maxFileSize,
    displayNote,
  } = props;
  const theme = useTheme();
  const { showSnackbar } = useSnackbar();
  const [openDialog, setOpenDialog] = useState(false);

  const handleOpenDialog = () => {
    setOpenDialog(true);
  };

  const handleCloseDialog = () => {
    setOpenDialog(false);
  };

  //Handling files upload and delete
  const [uploadedFiles, setUploadedFiles] = useState([]);
  const [isLoading, setIsLoading] = useState(false);

  const uploadAttachment = async (files) => {
    setIsLoading(true);
    console.log("Inside uploadAttachment:", files, files?.length);
    try {
      var bodyFormData = new FormData();
      for (let i = 0; i < files.length; i++) {
        bodyFormData.append("file", files[i].file);
      }
      console.log("bodyFormData", bodyFormData);

      const config = { headers: { "Content-Type": "multipart/form-data" } };
      const res = await axios.post(
        `${process.env.REACT_APP_HOST_API_KEY}uploadAttachment`,
        bodyFormData,
        config
      );
      console.log("Response Details: ", res.data);
      if (res.data.statusCode == 200 && res.data.status === true) {
        setUploadedFiles([...uploadedFiles, ...files]);
        onUpload(res.data.result, "upload");
      } else {
        showSnackbar("Opps, something went wrong", "error");
      }
    } catch (error) {
      showSnackbar("Opps, something went wrong", "error");
      console.log(error.message);
    }
    setIsLoading(false);
  };

  const handleDeleteFile = (index) => {
    const updatedFiles = [...uploadedFiles];
    updatedFiles.splice(index, 1);
    setUploadedFiles(updatedFiles);
    onUpload(updatedFiles, "delete");
  };

  // function nameLengthValidator(file) {
  //   console.log("Inside name length validator: ", file);
  //   if (file.name.length > 30) {
  //     return showSnackbar("File length large", "info");
  //   }
  //   return null;
  // }

  //For viewing files:
  const [clickedFile, setClickedFile] = useState();
  const [clickedFileName, setClickedFileName] = useState("");
  const [openDocViewer, setOpenDocViewer] = useState(false);

  const handleViewFile = (file) => {
    console.log("Clicked file: ", file);
    setClickedFileName(file.name);
    setClickedFile(file);
    setOpenDocViewer(true);
  };

  const handleCloseDocViewer = () => {
    setOpenDocViewer(false);
  };

  console.log("Uploaded files: ", uploadedFiles);

  return (
    <>
      <React.Fragment>
        <Grid container justifyContent="center" alignItems="center">
          <Grid item>
            <Button
              sx={{ minWidth: 50 }}
              variant="outlined"
              onClick={handleOpenDialog}
              startIcon={<AttachFileIcon />}
            >
              {buttonName ? buttonName : "Attachments"}
            </Button>
          </Grid>
        </Grid>

        <Dialog
          open={openDialog}
          onClose={handleCloseDialog}
          sx={{
            "& .MuiDialog-paper": {
              width: "100%",
              //maxHeight: 500,
              border: "1.5px solid black",
            },
          }}
          maxWidth={maxWidth} // lg,md...
          fullWidth={fullWidth} // boolean
          PaperComponent={isDraggable ? PaperComponent : Paper}
          scroll={"paper"}
          fullScreen={useMediaQuery(theme.breakpoints.down("sm"))}
        >
          <DialogTitle
            sx={{
              cursor: isDraggable ? "move" : "default",
            }}
            id="files-dialog-title"
          >
            <CloseIcon
              sx={{
                float: "right",
                ":hover": {
                  color: "white",
                  backgroundColor: "#286cb4",
                  cursor: "pointer",
                },
              }}
              onClick={handleCloseDialog}
            />
            <Typography
              //variant="h1"
              sx={{
                fontWeight: "bold",
                fontSize: "25px",
                textDecoration: "underline",
              }}
            >
              {dialogHeading ? dialogHeading : "Upload Files:"}
            </Typography>
          </DialogTitle>
          <DialogContent>
            <Grid
              container
              direction="row"
              spacing={1}
              //justifyContent="flex-end"
            >
              <Grid item xs={12} sm={12} md={3} lg={3}>
                <Box sx={{ maxHeight: "300px", overflow: "auto", padding: 2 }}>
                  <DropzoneAreaBase
                    fileObjects={uploadedFiles}
                    onAdd={uploadAttachment}
                    onDelete={(e, index) => {
                      console.log("S.No. of deleted file: ", index + 1);
                      handleDeleteFile(index);
                    }}
                    //
                    acceptedFiles={filesAccepted}
                    maxFileSize={maxFileSize * 1024 * 1024}
                    filesLimit={maxNumberOfFiles}
                    //
                    dropzoneText={dropzoneText}
                    showPreviewsInDropzone={showPreviewsInDropzone}
                    showPreviews={false}
                    showFileNames={false}
                    showFileNamesInPreview={false}
                    showAlerts={true}
                    // clearOnUnmount={false}
                    // dropzoneProps={{
                    //   validator: nameLengthValidator,
                    // }}
                  />
                </Box>
                {displayNote && (
                  <Box sx={{ my: 1 }}>
                    <Typography
                      sx={{ textDecoration: "underline" }}
                      fontWeight="bold"
                      variant="h4"
                    >
                      Note:
                    </Typography>
                    <Typography variant="body2">
                      1. Maximum No. of files allowed are {maxNumberOfFiles}.
                    </Typography>
                    <Typography variant="body1">
                      2. Accepted file types: {filesAccepted.join(", ")}.
                    </Typography>
                  </Box>
                )}
              </Grid>

              <Grid item xs={12} sm={12} md={9} lg={9}>
                <Box
                  sx={{
                    width: "100%",
                    display: "table",
                    tableLayout: "fixed",
                    border: "1px solid black",
                  }}
                >
                  <TableContainer sx={{ maxHeight: 440 }}>
                    <Table stickyHeader>
                      <TableHead>
                        <TableRow>
                          {displaySNo && (
                            <StyledTableCell>S.No</StyledTableCell>
                          )}
                          <StyledTableCell>File Name</StyledTableCell>
                          {displayFileSize && (
                            <StyledTableCell>File Size</StyledTableCell>
                          )}
                          {displayThumbnail && (
                            <StyledTableCell>Thumbnail</StyledTableCell>
                          )}
                          <StyledTableCell>Action</StyledTableCell>
                        </TableRow>
                      </TableHead>
                      <TableBody>
                        {uploadedFiles.map((file, index) => (
                          <TableRow key={index}>
                            {displaySNo && (
                              <StyledTableCell>{index + 1}.</StyledTableCell>
                            )}
                            <StyledTableCell>
                              <Link
                                sx={{ cursor: "pointer" }}
                                //href="javascript:void(0)"
                                onClick={() => {
                                  handleViewFile(file?.file);
                                }}
                              >
                                {file?.file?.name}
                              </Link>
                            </StyledTableCell>
                            {displayFileSize && (
                              <StyledTableCell>
                                {file?.file?.size
                                  ? `${(file?.file?.size / 1024).toFixed(2)} KB`
                                  : "N/A"}
                              </StyledTableCell>
                            )}
                            {displayThumbnail && (
                              <StyledTableCell>
                                {file?.file?.type === "application/pdf" ? (
                                  <IconButton
                                    onClick={() => handleViewFile(file?.file)}
                                    aria-label="fingerprint"
                                    id="finger_print"
                                    color="secondary"
                                  >
                                    <PictureAsPdf />
                                  </IconButton>
                                ) : (
                                  <img
                                    onClick={() => handleViewFile(file?.file)}
                                    style={{ cursor: "pointer" }}
                                    src={URL.createObjectURL(file?.file)}
                                    alt="Thumbnail"
                                    height="50"
                                  />
                                )}
                              </StyledTableCell>
                            )}
                            <StyledTableCell>
                              <Button
                                variant="outlined"
                                color="secondary"
                                onClick={() => handleDeleteFile(index)}
                              >
                                Delete
                              </Button>
                            </StyledTableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </TableContainer>
                </Box>
              </Grid>
            </Grid>
          </DialogContent>
          <DialogActions>
            <Button variant="contained" onClick={handleCloseDialog}>
              Close
            </Button>
          </DialogActions>
          {isLoading && <FaceBookCircularProgress />}
        </Dialog>

        <Dialog
          fullScreen
          open={openDocViewer}
          onClose={handleCloseDocViewer}
          sx={{ height: "100%", width: "100%" }}
        >
          <DocViewer
            file={clickedFile}
            fileName={clickedFileName}
            isClosed={handleCloseDocViewer}
          />
        </Dialog>
      </React.Fragment>
    </>
  );
};

export default Attachments;
