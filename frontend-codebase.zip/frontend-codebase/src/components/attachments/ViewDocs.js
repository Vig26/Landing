import React, { useEffect, useState } from "react";
import { Typography, Alert, Link, Grid } from "@mui/material";
import axios from "axios";
//
import { useSnackbar } from "../../../../components/Snackbar";
import CustomDialog from "../modal/CustomDialog";

export default function ViewDocs({
  openAttachments,
  handleCloseDialog,
  attachmentsHeading,
  filesData,
}) {
  const { showSnackbar } = useSnackbar();
  console.log("Files data in viewDocs: ", filesData);

  const ContentOfDialog = () => {
    const handleViewFile = (fileName, filePath) => {
      //const payload = new FormData();
      //payload.append("filePath", filePath);
      console.log("File Name: ", fileName, fileName.split("."));

      let FileType = "";
      let getFileType = fileName.split(".").pop();
      if (getFileType == "pdf") {
        FileType = "application/pdf";
      } else if (
        getFileType == "jpg" ||
        getFileType == "jpeg" ||
        getFileType == "png"
      ) {
        FileType = "image/jpeg";
      }

      axios
        .post(`${process.env.REACT_APP_HOST_API_KEY}download`, null, {
          params: {
            filePath,
          },
          responseType: "blob",
          // headers: {
          //   Accept: "application/octet-stream",
          // },
        })
        .then((response) => {
          console.log("Files res in ViewDocs:", response.data);

          const contentType = response.headers.get("Content-Type");
          console.log("Content Type: ", contentType);
          const viewblob = new Blob([response.data], { type: FileType });
          console.log("Blob: ", viewblob, "Blob type: ", viewblob.type);
          // const viewblob = new Blob([response.data], {
          //   // type: "application/pdf",
          //   //type: contentType,
          //   type: "image/png",
          // });
          const url = URL.createObjectURL(viewblob);
          console.log(url, "url");
          window.open(url, "_blank"); // "noopener,noreferrer" check this once

          // //For downloading the file:
          // const blob = new Blob([response.data]);
          // // Create a link element
          // const a = document.createElement("a");
          // a.href = window.URL.createObjectURL(blob);
          // a.download = fileName;

          // // Append the link element to the body
          // document.body.appendChild(a);

          // // Simulate a click on the link to trigger the download
          // a.click();

          // // Remove the link element from the body
          // document.body.removeChild(a);
        })
        .catch((error) => {
          console.log("Download error: ", error);
          showSnackbar("Opps, something went wrong", "error");
        });
    };

    return (
      <>
        {filesData.length === 0 ? (
          // <Typography >Files not found</Typography>
          <Alert severity="info">Attachments not found</Alert>
        ) : (
          <>
            {/* <DownloadButton
              fileName={"File1"}
              filePath={
                "89R0AaaklItx6U7Dp0qIdP4AmqaZaUbzOjf+GiHUulrIGPC/KFEtc6sR5q6m20E5YQpLgxFn1LmsfEjN81jWo1b8PdqNnA7gRlbTuXGEIF1LirLBRwcajpRcxa6tTKDLf01MVoUUVVDm+J+yYBZvgzfwQMKvMzH4LeB0aw6PRvk="
              }
            /> */}
            <Grid container direction="column" spacing={1}>
              {filesData.map((fileItem, index) => (
                <Grid item>
                  <Typography fontSize="16px">
                    {index + 1 + ") "}
                    <Link
                      sx={{ cursor: "pointer" }}
                      //href="javascript:void(0)"
                      onClick={() => {
                        handleViewFile(fileItem.fileName, fileItem.filePath);
                      }}
                    >
                      {fileItem.fileName}
                    </Link>
                  </Typography>
                </Grid>
              ))}
            </Grid>
          </>
        )}
      </>
    );
  };
  return (
    <>
      <CustomDialog
        open={openAttachments}
        handleClose={handleCloseDialog}
        heading={attachmentsHeading}
        ContentOfDialog={<ContentOfDialog />}
      />
      {/* <ContentOfDialog /> */}
    </>
  );
}
