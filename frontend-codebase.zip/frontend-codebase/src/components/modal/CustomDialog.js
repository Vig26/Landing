import { Typography, Box } from "@mui/material";
import Button from "@mui/material/Button";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import DialogTitle from "@mui/material/DialogTitle";
import * as React from "react";

export default function CustomDialog({
  open,
  handleClose,
  ContentOfDialog,
  heading,
  fullWidth,
  maxWidth,
}) {
  //console.log("Full Width: ", fullWidth);
  return (
      <Dialog
        open={open}
        onClose={handleClose}
        aria-labelledby="responsive-dialog-title"
        maxWidth={maxWidth}
        fullWidth={fullWidth}
      >
        <Box
          sx={{
            border: "15px solid #e0e0e0",
            boxShadow: "0 0 0 2px #c0c0c0 inset",
            // boxShadow: "0 0 0 2px #c0c0c0 ,0 0 0 10px #e0e0e0 inset",
            //backgroundColor: "lightGrey",
          }}
        >
          <DialogTitle id="responsive-dialog-title">
            <Typography
              fontSize="20px"
              fontWeight="bold"
              sx={{ textDecoration: "underline" }}
            >
              {heading}
            </Typography>
          </DialogTitle>
          <DialogContent>
            {/* <DialogContentText> */}
            {ContentOfDialog}
            {/* </DialogContentText> */}
          </DialogContent>
          <DialogActions>
            <Button autoFocus onClick={handleClose}>
              Close
            </Button>
          </DialogActions>
        </Box>
      </Dialog>
  );
}
