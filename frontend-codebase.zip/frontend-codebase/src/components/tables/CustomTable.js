import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  Typography,
  Box,
  Link,
  Card,
  CardContent,
  Paper,
  makeStyles,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TableSortLabel,
  TablePagination,
  Radio,
  tableCellClasses,
  styled,
} from "@mui/material";

const StyledTableCell = styled(TableCell)(({ theme }) => ({
  [`&.${tableCellClasses.head}`]: {
    backgroundColor: "#2169b3",
    color: theme.palette.common.white,
  },
  [`&.${tableCellClasses.body}`]: {
    fontSize: 14,
    //height: "5px",
  },
}));

export const CustomTable = ({
  columns,
  dataFromApi,
  title,
  onRadioChange,
  includePagination,
  tableFor,
}) => {
  const [selectedRow, setSelectedRow] = useState(null);
  const [selectedRow2, setSelectedRow2] = useState(null);
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(
    includePagination ? 5 : 100000
    //Number.POSITIVE_INFINITY
  );

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const navigate = useNavigate();

  function pad(num, size) {
    num = num.toString();
    while (num.length < size) num = "0" + num;
    return num;
  }

  let data = [];
  dataFromApi.map((row, index) => {
    if (tableFor === "Family Details") {
      data.push({
        select: (
          <Radio
            checked={selectedRow === row.residentId}
            onChange={() => {
              setSelectedRow(row.residentId);
              onRadioChange(row, index, tableFor);
            }}
            value={row.residentId}
          />
        ),
        name: row.name,
        gender: row.gender,
        relationship: row.relationship,
      });
    } else if (tableFor === "Case Details") {
      data.push({
        select: (
          <Radio
            checked={selectedRow2 === row.caseId}
            onChange={() => {
              setSelectedRow2(row.caseId);
              onRadioChange(row, index, tableFor);
            }}
            value={row.caseId}
          />
        ),
        caseId: row.caseId,
        hospitalName: row.hospitalName,
      });
    }
  });

  return (
    <Box sx={{ mt: "15px", mr: "30px", ml: "30px" }}>
      <Typography
        sx={{ mb: "5px", textDecoration: "underline", fontSize: "20px" }}
      >
        <b>{title}</b>
      </Typography>
      {/* <Box sx={{ overflow: "auto" }}>
        <Box sx={{ width: "100%", display: "table", tableLayout: "fixed" }}> */}
      <Paper sx={{ width: "100%", overflow: "auto" }}>
        <TableContainer
          //component={Paper}
          sx={{ maxHeight: "200px" }}
        >
          <Table stickyHeader aria-label="sticky table">
            <TableHead>
              <TableRow>
                {columns.map((column) => (
                  <StyledTableCell
                    key={column.id}
                    align={column.align}
                    style={{
                      minWidth: column.minWidth,
                      fontWeight: "bold",
                      fontSize: "15px",
                    }}
                  >
                    {column.label}
                  </StyledTableCell>
                ))}
              </TableRow>
            </TableHead>
            <TableBody>
              {data
                .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                .map((row, index) => {
                  return (
                    <TableRow hover role="checkbox" tabIndex={-1} key={row.id}>
                      {columns.map((column) => {
                        const value = row[column.id];
                        return (
                          <>
                            {column.id == "srNo" ? (
                              <TableCell key={column.id} align={column.align}>
                                {index + 1 + page * rowsPerPage}
                              </TableCell>
                            ) : column.id == "id" ? (
                              <TableCell key={column.id} align={column.align}>
                                <Link
                                  underline="hover"
                                  color="inherit"
                                  onClick={() => {
                                    navigate("/message", {
                                      state: {
                                        id: row.id,
                                        type: "CLOSED",
                                      },
                                    });
                                  }}
                                >
                                  {`CHAT${pad(row.id, 10)}`}
                                </Link>
                              </TableCell>
                            ) : (
                              <TableCell key={column.id} align={column.align}>
                                {column.format && typeof value === "number"
                                  ? column.format(value)
                                  : value}
                              </TableCell>
                            )}
                          </>
                        );
                      })}
                    </TableRow>
                  );
                })}
            </TableBody>
          </Table>
        </TableContainer>
      </Paper>
      {includePagination && (
        <TablePagination
          rowsPerPageOptions={[5, 10, 25]}
          component="div"
          count={data.length}
          rowsPerPage={rowsPerPage}
          page={page}
          onPageChange={handleChangePage}
          onRowsPerPageChange={handleChangeRowsPerPage}
        />
      )}
      {/* </Box>
      </Box> */}
    </Box>
  );
};
