const AlertMessages = {
  ERROR1: "An error occured",
  ERROR2: "Opps, something went wrong",
  DETAILS_FETCHED: "Details fetched successfully",
  NO_RECORD: "No record found",
  ACTION_TAKEN: "Action taken successfully",
};

export default AlertMessages;
