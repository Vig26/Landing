export const PORTAL_NAMES={
   PORTAL_NAME:"React Portal"
}


export const HEADINGS = {

};
