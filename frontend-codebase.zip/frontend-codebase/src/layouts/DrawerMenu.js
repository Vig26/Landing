import DashboardIcon from "@mui/icons-material/Dashboard";
import ExpandLessIcon from "@mui/icons-material/ExpandLess";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import PersonIcon from "@mui/icons-material/Person";
import Box from "@mui/material/Box";
import Collapse from "@mui/material/Collapse";
import List from "@mui/material/List";
import ListItem from "@mui/material/ListItem";
import ListItemIcon from "@mui/material/ListItemIcon";
import ListItemText from "@mui/material/ListItemText";
import React, { lazy, useEffect, useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { hasChildren } from "../utils/MenuUtils";
import { store } from ".././store";
import { useSelector } from "react-redux";
import * as MuiIcons from "@mui/icons-material";

export default function DrawerMenu() {
  const [selectedItem, setSelectedItem] = useState(null);
  const [selectedChild, setSelectedChild] = useState(null);
  const location = useLocation();
  const user = useSelector((state) => state.user);
  const [items3, setItems3] = useState([]);
  const [items2, setItems2] = useState([]);
  const [menu1, setMenu1] = useState([]);
  const navigate = useNavigate();

  var unique_values = [];
  var myObject = null;
  var myObject1 = [
    {
      icon: MuiIcons["Dashboard"],
      menuName: "Dashboard",
      link: "/home",
    },
  ];

  var filteredData1 = [];

  useEffect(() => {
    if (store.getState().user.status === "success") {
      console.log("subMenuList", user.data.data.userdetails.subMenuList);
      console.log(Object.keys(user.data.data.userdetails.menuList).length);
    } else {
      navigate("/");
    }

    fillMenu();
    const selectedMenu = menu1.find(
      (item) => item.menuCode === location.pathname
    );

    setSelectedItem(selectedMenu);
  }, []);

  const fillMenu = async () => {
    // unique_values = res.data.result.subMenuList
    //         .map((item) => item.parentName)
    //         .filter(
    //             (value, index, current_value) => current_value.indexOf(value) === index
    //         );
    //     console.log(unique_values);
    //     setItems3(unique_values);
    if (store.getState().user.status === "success") {
      var i;

      for (
        i = 0;
        i < Object.keys(user.data.data.userdetails.menuList).length;
        i++
      ) {
        myObject1.push({
          icon: MuiIcons[user.data.data.userdetails.menuList[i].icon],
          menuName: user.data.data.userdetails.menuList[i].menuName,
          link: user.data.data.userdetails.menuList[i].link,
          items: user.data.data.userdetails.subMenuList.filter(
            (x) =>
              x.parentMenuId === user.data.data.userdetails.menuList[i].menuId
          ),
        });
      }
    } else {
      navigate("/");
    }
    console.log(myObject1);
    //    filteredData1= res.data.result.subMenuList.filter(item => item.parentName.includes(unique_values[0]));
    //    setItems2(filteredData1);
    //       myObject = [{
    //         icon: <DashboardIcon />,
    //         name: "Dashboard",
    //         menucode: "/home",
    //         role: "-",
    //       }, { icon: <PersonIcon />,
    //       name: unique_values[0],
    // items: filteredData1

    //         }];

    console.log(myObject1);
    setMenu1(myObject1);
  };
  const handleSelectItem = (item) => {
    setSelectedItem(item);
    setSelectedChild(null);
  };
  const [open1, setOpen1] = useState(false);

  console.log(menu1);
  localStorage.setItem("menulist", menu1);
  return menu1?.map(
    (item, key) => (
      // {false ? (
      <Box>
        <MenuItem
          key={key}
          item={item}
          selected={item === selectedItem}
          onSelect={handleSelectItem}
          selectedChild={selectedChild}
          setSelectedChild={setSelectedChild}
        />
      </Box>
    )
    // ) : <></>}
  );
}

const MenuItem = ({
  item,
  selected,
  onSelect,
  selectedChild,
  setSelectedChild,
}) => {
  const Component = hasChildren(item) ? MultiLevel : SingleLevel;
  //console.log(item.role);
  return (
    <Component
      item={item}
      selected={selected}
      onSelect={onSelect}
      selectedChild={selectedChild}
      setSelectedChild={setSelectedChild}
    />
  );
};
//2169b3
const SingleLevel = ({ item, selected, onSelect }) => {
  console.log(item);
  //
  return (
    <Link
      to={item.link}
      style={{
        textDecoration: "none",
        display: "block",
        color: selected ? "#2169b3" : "#666666",
      }}
    >
      <ListItem
        button
        onClick={() => onSelect(item)}
        style={{ backgroundColor: selected ? "#f2f9ff" : "inherit" }}
      >
        <ListItemIcon style={{ color: selected ? "#2169b3" : "#666666" }}>
          {item.icon ? <item.icon /> : null}
        </ListItemIcon>
        <Link
          to={item.link}
          style={{
            textDecoration: "none",
            display: "block",
            color: selected ? "#2169b3" : "#666666",
          }}
        >
          <ListItemText primary={item.menuName} />
        </Link>
      </ListItem>
    </Link>
  );
};

const MultiLevel = ({
  item,
  selected,
  onSelect,
  selectedChild,
  setSelectedChild,
}) => {
  const navigate = useNavigate();
  console.log(item);
  console.log(localStorage.getItem("role"));
  const { items: children } = item;
  const [open, setOpen] = useState(false);

  const handleToggle = () => {
    setOpen((prev) => !prev);
  };

  const handlenavigate = (link) => {
    navigate(link);
  };
  const handleEvent = () => {
    handleToggle();
    onSelect(item);
  };
  return (
    <React.Fragment>
      <ListItem
        button
        onClick={handleEvent}
        style={{ backgroundColor: selected ? "#f2f9ff" : "inherit" }}
      >
        <ListItemIcon style={{ color: selected ? "#2169b3" : "#666666" }}>
          {item.icon ? <item.icon /> : null}
        </ListItemIcon>
        <ListItemText
          primary={item.menuName}
          style={{
            color: selected ? "#2169b3" : "#666666",
            fontFamily: "Lato,serif",
          }}
        />
        {open ? <ExpandLessIcon /> : <ExpandMoreIcon />}
      </ListItem>
      <Collapse in={open} timeout="auto" unmountOnExit>
        <List component="div" disablePadding>
          {children.map((child, key) => (
            <Link
              onClick={() => setSelectedChild(child)}
              to={child.link}
              style={{
                textDecoration: "none",
                display: "block",
                color: selectedChild === child ? "#2169b3" : "inherit",
              }}
            >
              <MenuItem
                key={key}
                item={child}
                href={child.link}
                component={child.link}
                selected={child === selectedChild}
                onSelect={setSelectedChild}
                onClick={(child) => child.link}
              />
            </Link>
          ))}
        </List>
      </Collapse>
    </React.Fragment>
  );
};
