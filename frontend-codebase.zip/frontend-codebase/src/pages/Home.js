import React from "react";
import DashboardCards from "../components/DashboardCards";

const Home = () => {
  return (
    <>
      <DashboardCards />
    </>
  );
};

export default Home;
