// import React, { useState } from "react";
// import Avatar from '@mui/material/Avatar';
// import Button from '@mui/material/Button';
// import CssBaseline from '@mui/material/CssBaseline';
// import TextField from '@mui/material/TextField';
// import FormControlLabel from '@mui/material/FormControlLabel';
// import Checkbox from '@mui/material/Checkbox';
// import Link from '@mui/material/Link';
// import Paper from '@mui/material/Paper';
// import Box from '@mui/material/Box';
// import Grid from '@mui/material/Grid';
// import LockOutlinedIcon from '@mui/icons-material/LockOutlined';
// import Typography from '@mui/material/Typography';
// import {Routes, Route, useNavigate} from 'react-router-dom';

// import Visibility from '@mui/icons-material/Visibility';
// import VisibilityOff from '@mui/icons-material/VisibilityOff';
// import FormControl from '@mui/material/FormControl';
// import OutlinedInput from '@mui/material/OutlinedInput';
// import InputLabel from '@mui/material/InputLabel';
// import InputAdornment from '@mui/material/InputAdornment';
// import IconButton from '@mui/material/IconButton';

// import bgImage from "../../assets/images/home.png";
// import logoImage from "../../assets/images/logo.png";

// import logoRight from "../../assets/images/logo_right.png";
// import logoLeft from "../../assets/images/logo_left.png";
// import Container from '@mui/material/Container';
// import { maxHeight } from "@mui/system";

// import * as Yup from "yup";
// import { yupResolver } from "@hookform/resolvers/yup";
// import CircularProgress from '@mui/material/CircularProgress';
// import { decrypt, encrypt } from "../../utils/common";
// import { SnackbarProvider, useSnackbar } from "../../components/Snackbar";
// import { useForm, Controller } from "react-hook-form";
// import axios from "../../utils/axios1";

// export default function SignInSide() {
//   const { showSnackbar } = useSnackbar();
//   const [showPassword, setShowPassword] = useState(false);
//   const [loading, setLoading] = useState(false);
//   const handleClickShowPassword = () => setShowPassword((show) => !show);
//   const validationSchema = Yup.object().shape({
//     loginId: Yup.string()
//       .required("Username is required")
//       .min(3, "Username must be at least 3 characters")
//       .max(20, "Username must not exceed 20 characters"),

//     loginPWD: Yup.string()
//       .required("Password is required")
//       .min(3, "Password must be at least 3 characters")
//       .max(20, "Password must not exceed 20 characters"),
//   });
//   const {
//     register,
//     control,
//     handleSubmit,
//     formState: { errors },
//   } = useForm({
//     resolver: yupResolver(validationSchema),
//   });

//   const handleMouseDownPassword = (event) => {
//     event.preventDefault();
//   };

//   const navigate = useNavigate();
//   const navigateToHome = () => {
//     navigate('/home');
//   };

//   const onSubmit = async (data) => {
//     const body1 = {
//       userName: data.loginId ,
//       password:encrypt(data.loginPWD).toString()
//     }
//     console.log(decrypt('UUrDoU1Z4FPT+gsNEZNGpw=='))
//     console.log(body1);
//     const res = await axios.post('/login',body1)
//     console.log(res);
//     if (res.data.code==200)
//     {
//       showSnackbar(res.data.message, "success");
//       navigateToHome();
//     }
//     else if (res.data.code==400)
//     {
//       showSnackbar(res.data.message, "error");
//     }
//   };

//   return (
//     <Grid container component="main" sx={{ height: '100vh' }}>
//       <CssBaseline />
//       <Grid
//         item
//         xs={false}
//         sm={4}
//         md={7}
//         sx={{
//           backgroundImage: `url(${bgImage})`,
//           backgroundRepeat: 'no-repeat',
//           filter: "grayscale(80%)",
//           backgroundColor: (t) =>
//             t.palette.mode === 'light' ? t.palette.grey[50] : t.palette.grey[900],
//           backgroundSize: 'cover',
//           backgroundPosition: 'center',
//         }}
//       />
//       <Grid item xs={12} sm={8} md={5} component={Paper} elevation={6} square>
//         <Box
//           sx={{
//             my: 8,
//             mx: 4,
//             display: 'flex',
//             flexDirection: 'column',
//             alignItems: 'center',
//           }}
//         >
//           {/* <Avatar sx={{ m: 1, bgcolor: 'secondary.main' }}>
//             <LockOutlinedIcon />
//           </Avatar> */}
//           {/* <Avatar alt="logo" src={logoImage}/> */}
//           <Box
//               component="img"
//               sx={{
//                 // height: 233,
//                 width: 150,
//               }}
//               alt="Logo"
//               src={logoLeft}
//             />
//           <Typography sx={{fontSize:26,mt:3,fontWeight:600}}>
//             Sign In to Operations
//           </Typography>
//           <Box component="form" noValidate onSubmit={handleSubmit(onSubmit)} sx={{ mt: 1 }}>
//           <FormControl fullWidth>
//             <TextField
//               //required
//               id="loginId"
//               name="loginId"
//               label="username"
//               margin="dense"
//               {...register("loginId")}
//               error={errors.loginId ? true : false}
//               helperText={errors.loginId?.message}
//             />
//             {/* <Typography variant="inherit" sx={{color:'#E04440'}}>
//               {errors.loginId?.message}
//             </Typography> */}
//           </FormControl>

//             <FormControl variant="outlined" fullWidth sx={{borderRadius:8,mt:2}}>
//               <InputLabel htmlFor="outlined-adornment-password">Password</InputLabel>
//               <OutlinedInput
//                 id="loginPWD"
//                 name="loginPWD"
//                 // label="password"
//                 margin="dense"
//                 {...register("loginPWD")}
//                 error={errors.loginPWD ? true : false}
//                 helperText={errors.loginPWD?.message}
//                 // id="outlined-adornment-password"
//                 type={showPassword ? 'text' : 'password'}
//                 endAdornment={
//                   <InputAdornment position="end">
//                     <IconButton
//                       aria-label="toggle password visibility"
//                       onClick={handleClickShowPassword}
//                       onMouseDown={handleMouseDownPassword}
//                       edge="end"
//                     >
//                       {showPassword ? <VisibilityOff /> : <Visibility />}
//                     </IconButton>
//                   </InputAdornment>
//                 }
//                 label="Password"
//               />
//               {/* <Typography variant="inherit" sx={{color:'#E04440'}}>
//                 {errors.loginPWD?.message}
//               </Typography> */}
//             </FormControl>

//             {loading  ? (
//               <Box sx={{ display: "flex", alignItems:'center', justifyContent: "center", width:'100%',pb:2 }}>
//                 <CircularProgress />
//               </Box>
//             ) : (
//               <Button
//                 fullWidth
//                 size="large"
//                 type="submit"
//                 variant="contained"
//                 sx={{
//                   mt: 3, mb: 2,
//                   height:45,
//                   fontSize:16,
//                   background: "#2169B2",
//                   // "&:hover": { backgroundColor: "#00BBBB" },
//                 }}
//               >
//                 Sign In
//               </Button>
//             )}

//             <Grid container>
//               <Grid item xs>
//               <FormControlLabel
//                 control={<Checkbox value="remember" color="primary" />}
//                 label="Remember me"
//               />
//               </Grid>
//               <Grid item sx={{fontSize:16,mt:1}}>
//                 <Link variant="body2" onClick={()=>navigate('/forgetPassword')}>
//                   Forgot password?
//                 </Link>
//               </Grid>
//             </Grid>
//           </Box>
//         </Box>
//       </Grid>
//     </Grid>
// );

// }

import React, { useState } from "react";
import { Link } from "react-router-dom";

// material-ui
import {
  Button,
  Checkbox,
  FormControl,
  FormControlLabel,
  Grid,
  IconButton,
  InputAdornment,
  InputLabel,
  OutlinedInput,
  Stack,
  TextField,
  Typography,
  alpha,
  styled,
  useMediaQuery,
} from "@mui/material";
import { useTheme } from "@mui/material/styles";
import { useNavigate } from "react-router-dom";
// project imports
import AuthCardWrapper from "../../components/cards/AuthCardWrapper";
// import AuthLogin from '../auth-forms/AuthLogin';
// import Logo from 'ui-component/Logo';
// import AuthFooter from 'ui-component/cards/AuthFooter';
import logoLeft from "../../assets/images/logo.png";
// assets
import { yupResolver } from "@hookform/resolvers/yup";
import Visibility from "@mui/icons-material/Visibility";
import VisibilityOff from "@mui/icons-material/VisibilityOff";
import Box from "@mui/material/Box";
import { sha256 } from "js-sha256";
import { useRef } from "react";
import { useForm } from "react-hook-form";
import { useDispatch } from "react-redux";
import * as Yup from "yup";
import { useSnackbar } from "../../components/Snackbar";
import { fetchUsers } from "../../store/userSlice";
import { PORTAL_NAMES } from "../../constants/constants";
// ================================|| AUTH3 - LOGIN ||================================ //
const drawerWidth = 280;
const Footer = styled("div", {
  shouldForwardProp: (prop) => prop !== "open",
})(({ theme, open }) => ({
  transition: theme.transitions.create(["margin", "width"], {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.leavingScreen,
  }),
  width: "100%",
  position: "fixed",
  top: "unset",
  bottom: 0,
  color: "white",
  backgroundColor: "black",
  textAlign: "center",
  size: "8px",
  ...(open && {
    width: `calc(100% - ${drawerWidth}px)`,
    marginLeft: `${drawerWidth}px`,
    transition: theme.transitions.create(["margin", "width"], {
      easing: theme.transitions.easing.easeOut,
      duration: theme.transitions.duration.enteringScreen,
    }),
  }),
}));

const RedditTextField = styled((props) => (
  <TextField InputProps={{ disableUnderline: true }} {...props} />
))(({ theme }) => ({
  "& .MuiFilledInput-root": {
    overflow: "hidden",
    borderRadius: 4,
    backgroundColor: theme.palette.mode === "light" ? "#F3F6F9" : "#1A2027",
    border: "1px solid",
    borderColor: theme.palette.mode === "light" ? "#E0E3E7" : "#2D3843",
    transition: theme.transitions.create([
      "border-color",
      "background-color",
      "box-shadow",
    ]),
    "&:hover": {
      backgroundColor: "transparent",
    },
    "&.Mui-focused": {
      backgroundColor: "transparent",
      boxShadow: `${alpha(theme.palette.primary.main, 0.25)} 0 0 0 2px`,
      borderColor: theme.palette.primary.main,
    },
  },
}));

const Login = () => {
  const passwordRef = useRef();
  let salt = "";
  const { showSnackbar } = useSnackbar();
  const validationSchema = Yup.object().shape({
    loginId: Yup.string()
      .required("Username is required")
      .min(3, "Username must be at least 3 characters")
      .max(30, "Username must not exceed 30 characters"),

    loginPWD: Yup.string()
      .required("Password is required")
      .min(3, "Password must be at least 3 characters")
      .max(30, "Password must not exceed 30 characters"),
  });
  const {
    register,
    control,
    handleSubmit,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(validationSchema),
  });
  const dispatch = useDispatch();
  const theme = useTheme();
  const matchDownSM = useMediaQuery(theme.breakpoints.down("md"));

  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const handleClickShowPassword = () => setShowPassword((show) => !show);

  const navigate = useNavigate();
  const navigateToHome = () => {
    // localStorage.setItem('user', response.data)
    //
  };
  const navigateToForgetPassword = () => {
    //navigate("/forgetPassword");
  };
  const randomString = () => {
    let length = 100;
    let chars =
      "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQsha256RSTUVWXYZ";
    var result = "";
    for (var i = length; i > 0; --i)
      result += chars[Math.floor(Math.random() * chars.length)];
    return result;
  };
  const onSubmit = async (data) => {
    // passwordRef.current.value = randomString();
    console.log(data);

    // const filteredData = jsonData.roles.find(
    //   (role) => role.role === data.loginId.toUpperCase()
    // );
    // console.log(filteredData);
    // if (!filteredData) {
    //   showSnackbar("Invalid User", "error");
    //   console.log("No such user");

    // } else {
    //   localStorage.setItem("role", filteredData.role);
    //   localStorage.setItem("username", filteredData.username);
    console.log(data.loginId);
    console.log(data.loginPWD);
    let plainText = data.loginPWD;
    let salt = randomString();
    let hash = sha256.hmac(salt, plainText);
    console.log("hash", hash);

    let request = {
      username: data.loginId,
      password: hash,
      password2: salt,
    };
    console.log(request);
    console.log("hiiiiiiiiiii");
    console.log(request);

    try {
      const res = await dispatch(fetchUsers(request));
      console.log("the result", res);

      if (res.payload.status == 200 && res.payload.data.status === true) {
        passwordRef.current.value = randomString();
        showSnackbar("Login Successful", "success");
        navigate("/home");
        //console.log(user);
        //localStorage.setItem("token", res.payload.data.token);
        // console.log("local storage", localStorage.length);
        // console.log(
        //   "local storage persist:root: ",
        //   "Length: ",
        //   localStorage.getItem("persist:root").length,
        //   "Type: ",
        //   typeof localStorage.getItem("persist:root"),
        //   "Data: ",
        //   localStorage.getItem("persist:root")
        // );
        // console.log(
        //   "local storage manageReducer: ",
        //   localStorage.getItem("persist:root")
        // );
        // for (let i = 0; i < localStorage.length; i++) {
        //   console.log(
        //     "local storage: ",
        //     localStorage.key(i) +
        //       "=[" +
        //       localStorage.getItem(localStorage.key(i)) +
        //       "]"
        //   );
        // }
      } else if (
        res.payload.status == 200 &&
        res.payload.data.status === false
      ) {
        setLoading(false);
        showSnackbar("Invalid User Name or password.", "error");
        //navigate("/");
      }
    } catch (error) {
      showSnackbar("Opps, something went wrong", "error");
      console.log(error.message);
    }

    //dispatch(fetchRegistration());
  };

  return (
    <Grid
      container
      direction="column"
      justifyContent="flex-end"
      sx={{ minHeight: "100vh" }}
    >
      <Grid item xs={12}>
        <Grid
          container
          justifyContent="center"
          alignItems="center"
          sx={{ minHeight: "calc(100vh - 68px)" }}
        >
          <Grid item sx={{ m: { xs: 1, sm: 3 }, mb: 0 }}>
            <AuthCardWrapper>
              <Grid
                container
                spacing={1}
                alignItems="center"
                justifyContent="center"
              >
                <Grid item sx={{ mb: 0 }}>
                  <Link to="#">
                    <img src={logoLeft} alt="Berry" width="100" />
                  </Link>
                </Grid>
                <Grid item xs={12}>
                  <Grid
                    container
                    direction={matchDownSM ? "column-reverse" : "row"}
                    alignItems="center"
                    justifyContent="center"
                  >
                    <Grid item>
                      <Stack
                        alignItems="center"
                        justifyContent="center"
                        spacing={1}
                      >
                        <Typography
                          color={theme.palette.secondary.main}
                          // gutterBottom
                          variant={matchDownSM ? "h3" : "h1"}
                        >
                          {PORTAL_NAMES.PORTAL_NAME}
                        </Typography>
                        <Typography
                          variant="caption"
                          fontSize="16px"
                          textAlign={matchDownSM ? "center" : "inherit"}
                        >
                          Sign In
                        </Typography>
                      </Stack>
                    </Grid>
                  </Grid>
                </Grid>
                <Grid item xs={12}>
                  <Box
                    component="form"
                    noValidate
                    onSubmit={handleSubmit(onSubmit)}
                    sx={{ mt: 1 }}
                  >
                    <FormControl fullWidth>
                      <TextField
                        //required
                        id="loginId"
                        name="loginId"
                        label="User Name"
                        margin="dense"
                        {...register("loginId")}
                        error={errors.loginId ? true : false}
                        //helperText={errors.loginId?.message}
                      />
                      <Typography variant="inherit" sx={{ color: "#E04440" }}>
                        {errors.loginId?.message}
                      </Typography>
                    </FormControl>
                    <FormControl
                      variant="outlined"
                      fullWidth
                      sx={{ borderRadius: 8, mt: 2 }}
                    >
                      <InputLabel htmlFor="outlined-adornment-password">
                        Password
                      </InputLabel>
                      <OutlinedInput
                        id="loginPWD"
                        name="loginPWD"
                        inputRef={passwordRef}
                        // label="password"
                        margin="dense"
                        sx={{ borderRadius: 8 }}
                        {...register("loginPWD")}
                        error={errors.loginPWD ? true : false}
                        //helperText={errors.loginPWD?.message}
                        // id="outlined-adornment-password"
                        type={showPassword ? "text" : "password"}
                        endAdornment={
                          <InputAdornment position="end">
                            <IconButton
                              aria-label="toggle password visibility"
                              onClick={handleClickShowPassword}
                              // onMouseDown={handleMouseDownPassword}
                              edge="end"
                            >
                              {showPassword ? (
                                <VisibilityOff />
                              ) : (
                                <Visibility />
                              )}
                            </IconButton>
                          </InputAdornment>
                        }
                        label="Password"
                      />
                      <Typography variant="inherit" sx={{ color: "#E04440" }}>
                        {errors.loginPWD?.message}
                      </Typography>
                    </FormControl>
                    <Grid container>
                      <Grid item xs>
                        <FormControlLabel
                          control={
                            <Checkbox value="remember" color="primary" />
                          }
                          label="Remember me"
                        />
                      </Grid>
                      {/* <Grid item sx={{ fontSize: 14, mt: 1 }}>
                        <Link
                          variant="body2"
                          onClick={navigateToForgetPassword}
                        >
                          Forgot password?
                        </Link>
                      </Grid> */}
                    </Grid>
                    <Button
                      fullWidth
                      size="large"
                      type="submit"
                      variant="contained"
                      // onClick={navigateToHome}
                      sx={{
                        mt: 3,
                        mb: 2,
                        height: 45,
                        fontSize: 14,
                        background: "#2169B2",
                      }}
                    >
                      Sign In
                    </Button>
                  </Box>
                </Grid>
              </Grid>
            </AuthCardWrapper>
          </Grid>
        </Grid>
      </Grid>
      <Footer position="fixed">
        <Typography noWrap component="div">
          {/* CMS {location.pathname} */}
          &copy; Site maintained by KPMG Advisory Services Pvt. Ltd. The
          contents are owned by Govt. of AP, India.
        </Typography>
      </Footer>
    </Grid>
  );
};

export default Login;
