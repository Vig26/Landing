import API from "./axios";
import {
  commonAPIEndpoints,
} from "./apiEndpoints";

//Higher order function:
const handleAPICall = async (call, apiName) => {
  try {
    console.info(`handleAPICall function is called for the api: ${apiName}`);
    const response = await call();
    //throw new Error("Test Error in api service");
    console.log("Response structure: ", response);
    if (!(response.status >= 200 && response.status < 300)) {
      // alert(
      //   `Network Error: \nFor the api: ${apiName} \nstatus: ${response.status} \nstatusText: ${response.statusText}`
      // );
      throw new Error("Network response was not ok");
    }
    const data = response.data;
    if (
      data.status !== true ||
      !(data.statusCode >= 200 && data.statusCode < 300)
    ) {
      // alert(
      //   `API Error: \nFor the api: ${apiName} \nstatus: ${data.status} \nstatusCode: ${data.statusCode}`
      // );
      throw new Error("API response was not ok");
    }
    return data;
  } catch (error) {
    console.error(
      `API call error caught in api service layer: \n ${error.message}`
    );
    throw error;
  }
};


export const APIService = {
  postFunction: (payload) =>
    handleAPICall(
      () => API.post(commonAPIEndpoints.apiEndPoint, payload),
      commonAPIEndpoints.apiEndPoint
    ),
  getFunction: () =>
    handleAPICall(
      () => API.get(commonAPIEndpoints.apiEndPoint),
      commonAPIEndpoints.apiEndPoint
    ),
};
