import axios from "axios";

const API = axios.create({
  baseURL: `${process.env.REACT_APP_HOST_API_KEY}`, //Development
  //baseURL: "https://", //UAT
  //baseURL: "https://", //PROD
  //headers:{},
  //timeout:,
});

// API.interceptors.request.use(
//   (config) => {
//     config.headers["Authorization"] = `Bearer ${localStorage.getItem("token")}`;
//     return config;
//   },
//   (error) => {
//     Promise.reject(error);
//   }
// );

export default API;
