package in.kpmg.sfdbappservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SfdbAppServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(SfdbAppServiceApplication.class, args);
	}

}
