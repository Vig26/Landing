package in.kpmg.sfdbappservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SfdbAppServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
